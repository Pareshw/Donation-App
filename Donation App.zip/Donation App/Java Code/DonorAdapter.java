package com.example.donation_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DonorAdapter extends RecyclerView.Adapter<DonorAdapter.MyViewHolder>
{
    Context context;
    ArrayList<Donor> donorArrayList;
    //String photoLink = "Click Here To See The Photo";

    public DonorAdapter(Context context, ArrayList<Donor> donorArrayList) {
        this.context = context;
        this.donorArrayList = donorArrayList;
    }

    @NonNull
    @Override
    public DonorAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DonorAdapter.MyViewHolder holder, int position)
    {
            Donor donor = donorArrayList.get(position);

            holder.tvUserName.setText(donor.Donor_Name);
            holder.tvUserRequirement.setText(donor.Requirement);
            holder.tvUserMobile.setText(donor.Donor_Mobile_No);
            //holder.tvUserPhoto.setText(photoLink);
    }

    @Override
    public int getItemCount() {
        return donorArrayList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvUserName,tvUserRequirement,tvUserMobile;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvUserRequirement = itemView.findViewById(R.id.tvUserRequirement);
            tvUserMobile = itemView.findViewById(R.id.tvUserMobile);
            //tvUserPhoto = itemView.findViewById(R.id.tvUserPhoto);
        }
    }
}
