package com.example.donation_app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;

public class DonorPortal extends AppCompatActivity
{
    ImageButton b4;
    Button b5;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donor_portal);
        b4 = findViewById(R.id.imageButton);
        b4.setOnClickListener(view -> {
            Intent intent = new Intent(DonorPortal.this,DonorRequirements.class);
            startActivity(intent);
        });

        b5 = findViewById(R.id.button4);
        b5.setOnClickListener(view -> {
            Intent intent = new Intent(DonorPortal.this,UserNgoRequirements.class);
            startActivity(intent);
        });
    }
}
