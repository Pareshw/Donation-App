package com.example.donation_app;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class NgoUserRequirement extends AppCompatActivity
{

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ngo_user_requirements);


    }
}
