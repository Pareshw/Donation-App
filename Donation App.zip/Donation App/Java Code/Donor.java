package com.example.donation_app;

public class Donor
{
    String Donor_Name,Donor_Mobile_No,Requirement;//Photo;

    public Donor(){}

    public Donor(String donor_Name, String donor_Mobile_No, String requirement)//)
    {
        Donor_Name = donor_Name;
        Donor_Mobile_No = donor_Mobile_No;
        Requirement = requirement;
        //Photo = photo;
    }

//    public String getPhoto() {
//        return Photo;
//    }

//    public void setPhoto(String photo) {
//        Photo = photo;
//    }

    public String getDonor_Name() {
        return Donor_Name;
    }

    public void setDonor_Name(String donor_Name) {
        Donor_Name = donor_Name;
    }

    public String getDonor_Mobile_No() {
        return Donor_Mobile_No;
    }

    public void setDonor_Mobile_No(String donor_Mobile_No) {
        Donor_Mobile_No = donor_Mobile_No;
    }

    public String getRequirement() {
        return Requirement;
    }

    public void setRequirement(String requirement) {
        Requirement = requirement;
    }

    //    String NGO_Email,NGO_Mobile_No,NGO_Name,NGO_Password;
//
//    public Donor(){}
//
//    public Donor(String NGO_Email, String NGO_Mobile_No, String NGO_Name, String NGO_Password) {
//        this.NGO_Email = NGO_Email;
//        this.NGO_Mobile_No = NGO_Mobile_No;
//        this.NGO_Name = NGO_Name;
//        this.NGO_Password = NGO_Password;
//    }
//
//    public String getNGO_Email() {
//        return NGO_Email;
//    }
//
//    public void setNGO_Email(String NGO_Email) {
//        this.NGO_Email = NGO_Email;
//    }
//
//    public String getNGO_Mobile_No() {
//        return NGO_Mobile_No;
//    }
//
//    public void setNGO_Mobile_No(String NGO_Mobile_No) {
//        this.NGO_Mobile_No = NGO_Mobile_No;
//    }
//
//    public String getNGO_Name() {
//        return NGO_Name;
//    }
//
//    public void setNGO_Name(String NGO_Name) {
//        this.NGO_Name = NGO_Name;
//    }
//
//    public String getNGO_Password() {
//        return NGO_Password;
//    }
//
//    public void setNGO_Password(String NGO_Password) {
//        this.NGO_Password = NGO_Password;
//    }
}
