package com.example.donation_app;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.airbnb.lottie.LottieAnimationView;
import com.google.firebase.auth.FirebaseAuth;

public class NgoLogin extends AppCompatActivity
{
    Button ngo_login_button;
    LottieAnimationView lottieAnimationView;
    EditText email,password;
    FirebaseAuth firebaseAuth;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ngo_login);
        email = findViewById(R.id.editTextTextPersonName3);
        password = findViewById(R.id.editTextTextPassword3);
        lottieAnimationView = findViewById(R.id.lottieAnimationView1);
        firebaseAuth = FirebaseAuth.getInstance();
        ngo_login_button = findViewById(R.id.button16);
        ngo_login_button.setOnClickListener(view -> {
            String m_email = email.getText().toString().trim();
            String m_password = password.getText().toString().trim();

            if(TextUtils.isEmpty(m_email))
            {
                email.setError("Email is Required!!!");
            }
            if(TextUtils.isEmpty(m_password))
            {
                password.setError("Password is Required!!!");
            }
            if(m_password.length() < 6)
            {
                password.setError("Password Must Be >= 6 Characters");
            }

            firebaseAuth.signInWithEmailAndPassword(email.getText().toString(),password.getText().toString()).addOnCompleteListener(task -> {
               if(task.isSuccessful())
               {
                   Toast.makeText(NgoLogin.this, "Login In Success!", Toast.LENGTH_SHORT).show();
                   Intent intent = new Intent(NgoLogin.this,NgoPortal.class);
                   startActivity(intent);
               }
            }).addOnFailureListener(e -> Toast.makeText(NgoLogin.this, "Error in Sign In: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        });
    }
}
