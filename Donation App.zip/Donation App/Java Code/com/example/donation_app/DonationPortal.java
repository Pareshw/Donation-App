package com.example.donation_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class DonationPortal extends AppCompatActivity
{
    Button b2,b3;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donation_portal);
        b2 = findViewById(R.id.donor);
        b2.setOnClickListener(view -> {
            Intent intent = new Intent(DonationPortal.this,DonorLoginRegistration.class);
            startActivity(intent);
        });
        b3 = findViewById(R.id.ngo);
        b3.setOnClickListener(view -> {
            Intent intent = new Intent(DonationPortal.this,NgoLoginRegistration.class);
            startActivity(intent);
        });
    }
}
