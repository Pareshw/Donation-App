package com.example.donation_app;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class DonorRegistration extends AppCompatActivity
{
    Button b15;
    FirebaseAuth mAuth;
    EditText email,password,name,mobile_no;
    FirebaseFirestore firebaseFirestore;
    String userID;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donor_registration);
        email = findViewById(R.id.editTextTextEmailAddress);
        password = findViewById(R.id.editTextTextPassword);
        name = findViewById(R.id.editTextTextPersonName);
        mobile_no = findViewById(R.id.editTextPhone);
        mAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        b15 = findViewById(R.id.donor_reg);
        b15.setOnClickListener(view -> {
            String m_name = name.getText().toString().trim();
            String m_email = email.getText().toString().trim();
            String m_mobile_no = mobile_no.getText().toString().trim();
            String m_password = password.getText().toString().trim();

            if(TextUtils.isEmpty(m_name))
            {
                name.setError("Name is Required!!!");
            }
            if(TextUtils.isEmpty(m_email))
            {
                email.setError("Email is Required!!!");
            }
            if(TextUtils.isEmpty(m_mobile_no))
            {
                mobile_no.setError("Mobile No. is Required!!!");
            }
            if(TextUtils.isEmpty(m_password))
            {
                password.setError("Password is Required!!!");
            }
            if(m_password.length() < 6)
            {
                password.setError("Password Must Be >= 6 Characters");
            }

            mAuth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString()).addOnCompleteListener(task -> {
                if (task.isSuccessful())
                {
                    Toast.makeText(DonorRegistration.this, "Sign Up Successfully", Toast.LENGTH_SHORT).show();
                    userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
                    DocumentReference documentReference = firebaseFirestore.collection("donors").document(userID);
                    Map<String,Object> user = new HashMap<>();
                    user.put("Donor_Name",m_name);
                    user.put("Donor_Email",m_email);
                    user.put("Donor_Mobile_No",m_mobile_no);
                    user.put("Donor_Password",m_password);
                    documentReference.set(user).addOnSuccessListener(unused -> {
                        Toast.makeText(DonorRegistration.this, "SignUp success", Toast.LENGTH_SHORT).show();
                        AlertDialog.Builder builder = new AlertDialog.Builder(DonorRegistration.this);
                        builder.setCancelable(true);
                        builder.setTitle("Your Details are Successfully Send To the Admin.");
                        builder.setMessage("After an 24 Hour's You Get an Email from Our Side");
                        builder.setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.cancel());
                        builder.setPositiveButton("OK", (dialogInterface, i) -> onYesClick());
                        builder.show();
                    });
                }
                }).addOnFailureListener(e -> Toast.makeText(DonorRegistration.this, "Error in Signing up: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        });
    }

    private void onYesClick()
    {
        finishAffinity();
        System.exit(0);
    }
}