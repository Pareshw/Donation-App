package com.example.donation_app;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class NgoRegistration extends AppCompatActivity
{
    Button ngo_reg_button;
    EditText name,email,mobile_no,address,ngo_reg_no,password;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore db;
    String userID;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ngo_registration);
        firebaseAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        name = findViewById(R.id.editTextTextPersonName5);
        email = findViewById(R.id.editTextTextEmailAddress3);
        mobile_no = findViewById(R.id.editTextPhone3);
        address = findViewById(R.id.editTextTextPostalAddress2);
        ngo_reg_no = findViewById(R.id.editTextTextPersonName6);
        password = findViewById(R.id.editTextTextPassword4);
        ngo_reg_button = findViewById(R.id.button13);
        ngo_reg_button.setOnClickListener(view -> {
            String m_name = name.getText().toString().trim();
            String m_email = email.getText().toString().trim();
            String m_mobile_no = mobile_no.getText().toString().trim();
            String m_address = address.getText().toString().trim();
            String m_ngo_reg_no = ngo_reg_no.getText().toString().trim();
            String m_password = password.getText().toString().trim();

            if(TextUtils.isEmpty(m_name))
            {
                name.setError("Name is Required!!!");
            }
            if(TextUtils.isEmpty(m_email))
            {
                email.setError("Email is Required!!!");
            }
            if(TextUtils.isEmpty(m_mobile_no))
            {
                mobile_no.setError("Mobile No. is Required!!!");
            }
            if(TextUtils.isEmpty(m_address))
            {
                address.setError("Address is Required!!!");
            }
            if(TextUtils.isEmpty(m_ngo_reg_no))
            {
                ngo_reg_no.setError("NGO Registration No. is Required!!!");
            }
            if(TextUtils.isEmpty(m_password))
            {
                password.setError("Password is Required!!!");
            }
            if(m_password.length() < 6)
            {
                password.setError("Password Must Be >= 6 Characters");
            }

            firebaseAuth.createUserWithEmailAndPassword(m_email,m_password).addOnCompleteListener((task -> {
                if(task.isSuccessful())
                {
                    Toast.makeText(NgoRegistration.this, "Sign Up Successfully", Toast.LENGTH_SHORT).show();
                    userID = Objects.requireNonNull(firebaseAuth.getCurrentUser()).getUid();
                    DocumentReference documentReference = db.collection("users").document(userID);
                    Map<String,Object> user = new HashMap<>();
                    user.put("NGO_Name",m_name);
                    user.put("NGO_Email",m_email);
                    user.put("NGO_Mobile_No",m_mobile_no);
                    user.put("NGO_Address",m_address);
                    user.put("NGO_Reg_No",m_ngo_reg_no);
                    user.put("NGO_Password",m_password);
                    documentReference.set(user).addOnSuccessListener(unused -> {
                        AlertDialog.Builder builder = new AlertDialog.Builder(NgoRegistration.this);
                        builder.setCancelable(true);
                        builder.setTitle("Your Details are Successfully Send To the Admin.");
                        builder.setMessage("After an 48-72 Hour's You Get an Email from Our Side");
                        builder.setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.cancel());
                        builder.setPositiveButton("OK", (dialogInterface, i) -> onYesClick());
                        builder.show();
                    });
                }
            })).addOnFailureListener(e -> Toast.makeText(NgoRegistration.this, "Error in Signing UP :" + e.getMessage(), Toast.LENGTH_SHORT).show());
        });
    }
    private void onYesClick()
    {
        finishAffinity();
        System.exit(0);
    }
}
