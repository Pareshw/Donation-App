package com.example.donation_app;

public class Ngo
{
    String NGO_Name,NGO_Mobile_No,Requirement;

    public Ngo(){}
    public Ngo(String NGO_Name, String NGO_Mobile_No, String requirement)
    {
        this.NGO_Name = NGO_Name;
        this.NGO_Mobile_No = NGO_Mobile_No;
        this.Requirement = requirement;
    }

    public String getNGO_Name() {
        return NGO_Name;
    }

    public void setNGO_Name(String NGO_Name) {
        this.NGO_Name = NGO_Name;
    }

    public String getNGO_Mobile_No() {
        return NGO_Mobile_No;
    }

    public void setNGO_Mobile_No(String NGO_Mobile_No) {
        this.NGO_Mobile_No = NGO_Mobile_No;
    }

    public String getRequirement() {
        return Requirement;
    }

    public void setRequirement(String requirement) {
        Requirement = requirement;
    }
}
