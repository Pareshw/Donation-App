package com.example.donation_app;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class NgoPostRequirement extends AppCompatActivity
{
    EditText requirement;
    Button ngo_post;
    FirebaseStorage storage;
    StorageReference storageReference;
    FirebaseAuth mAuth;
    FirebaseFirestore firebaseFirestore;
    String userID;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ngo_requirements);
        requirement = findViewById(R.id.editTextTextMultiLine2);
        ngo_post = findViewById(R.id.button11);
        mAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        ngo_post.setOnClickListener(view -> {
            // String Code
            String m_requirement = requirement.getText().toString().trim();
            if(TextUtils.isEmpty(m_requirement))
            {
                requirement.setError("Data is Required!!!");
            }
            userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
            DocumentReference documentReference = firebaseFirestore.collection("users").document(userID);
            Map<String,Object> user = new HashMap<>();
            user.put("Requirement",m_requirement);
            documentReference.update(user).addOnSuccessListener(task -> Toast.makeText(NgoPostRequirement.this, "Data is Successfully Saved..", Toast.LENGTH_SHORT).show()).addOnFailureListener(t -> Toast.makeText(NgoPostRequirement.this, "Error Occurred: "+ t.getMessage(), Toast.LENGTH_SHORT).show());
            Intent intent = new Intent(NgoPostRequirement.this,ThankYou.class);
            startActivity(intent);
        });
    }
}