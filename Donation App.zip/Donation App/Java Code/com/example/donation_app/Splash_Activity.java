package com.example.donation_app;

import static java.lang.Thread.sleep;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;

import com.airbnb.lottie.LottieAnimationView;

public class Splash_Activity extends AppCompatActivity
{
    LottieAnimationView lottieAnimationView;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        lottieAnimationView = findViewById(R.id.lottie_splash);
        if (getSupportActionBar() != null)
        {
            getSupportActionBar().hide();
        }
        Thread thread = new Thread(() -> {
            try
            {
                sleep(8000);
                Intent intent = new Intent(Splash_Activity.this,MainActivity.class);
                startActivity(intent);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        });
        thread.start();
    }
}