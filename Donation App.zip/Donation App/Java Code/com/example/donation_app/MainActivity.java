package com.example.donation_app;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.get_started);
        b1.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this,DonationPortal.class);
            startActivity(intent);
        });
    }
    @Override
    public void onBackPressed()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Do you want to exit application?");
        builder.setPositiveButton("Yes", (dialog, id) -> finishAffinity());
        builder.setNegativeButton("No", (dialog, id) ->  dialog.cancel());
        builder.show();
    }
}
