package com.example.donation_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;

public class DonorPortal extends AppCompatActivity
{
    ImageButton b4;
    Button b5;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donor_portal);
        b4 = findViewById(R.id.imageButton);
        b4.setOnClickListener(view -> {
            Intent intent = new Intent(DonorPortal.this,DonorRequirements.class);
            startActivity(intent);
        });

        b5 = findViewById(R.id.button4);
        b5.setOnClickListener(view -> {
            Intent intent = new Intent(DonorPortal.this,NgoUserRequirement.class);
            startActivity(intent);
        });
    }
}
