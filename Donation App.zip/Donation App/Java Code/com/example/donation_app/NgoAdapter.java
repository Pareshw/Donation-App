package com.example.donation_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class NgoAdapter extends RecyclerView.Adapter<NgoAdapter.MyViewHolder1>
{
    Context context;
    ArrayList<Ngo> ngoArrayList;

    public NgoAdapter(Context context, ArrayList<Ngo> ngoArrayList)
    {
        this.context = context;
        this.ngoArrayList = ngoArrayList;
    }

    @NonNull
    @Override
    public NgoAdapter.MyViewHolder1 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_ngo,parent,false);
        return new MyViewHolder1(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NgoAdapter.MyViewHolder1 holder, int position)
    {
        Ngo ngo = ngoArrayList.get(position);
        holder.tvUserName1.setText(ngo.NGO_Name);
        holder.tvUserRequirement1.setText(ngo.Requirement);
        holder.tvUserMobile1.setText(ngo.NGO_Mobile_No);
    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public static class MyViewHolder1 extends RecyclerView.ViewHolder
    {
        TextView tvUserName1,tvUserRequirement1,tvUserMobile1;
        public MyViewHolder1(@NonNull View itemView) {
            super(itemView);
            tvUserName1 = itemView.findViewById(R.id.tvUserName1);
            tvUserRequirement1 = itemView.findViewById(R.id.tvUserRequirement1);
            tvUserMobile1 = itemView.findViewById(R.id.tvUserMobile1);
        }
    }
}
