package com.example.donation_app;

public class Donor
{
    String Donor_Name,Donor_Mobile_No,Requirement;

    public Donor(){}

    public Donor(String donor_Name, String donor_Mobile_No, String requirement)
    {
        Donor_Name = donor_Name;
        Donor_Mobile_No = donor_Mobile_No;
        Requirement = requirement;
    }

    public String getDonor_Name() {
        return Donor_Name;
    }

    public void setDonor_Name(String donor_Name) {
        Donor_Name = donor_Name;
    }

    public String getDonor_Mobile_No() {
        return Donor_Mobile_No;
    }

    public void setDonor_Mobile_No(String donor_Mobile_No) {
        Donor_Mobile_No = donor_Mobile_No;
    }

    public String getRequirement() {
        return Requirement;
    }

    public void setRequirement(String requirement) {
        Requirement = requirement;
    }

}
