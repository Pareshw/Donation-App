package com.example.donation_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.airbnb.lottie.LottieAnimationView;


public class DonorLoginRegistration extends AppCompatActivity
{
    Button b12,b13;
    LottieAnimationView lottieAnimationView;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donor_login_or_signup);
        lottieAnimationView = findViewById(R.id.lottieAnimationView3);
        b12 = findViewById(R.id.button3);
        b13 = findViewById(R.id.button9);
        b12.setOnClickListener(view -> {
            Intent intent = new Intent(DonorLoginRegistration.this,DonorLogin.class);
            startActivity(intent);
        });
        b13.setOnClickListener(view -> {
            Intent intent = new Intent(DonorLoginRegistration.this,DonorRegistration.class);
            startActivity(intent);
        });
    }

}
