package com.example.donation_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

public class NgoLoginRegistration extends AppCompatActivity
{
    Button ngo_login,ngo_reg;
    LottieAnimationView lottieAnimationView;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ngo_login_or_signup);
        lottieAnimationView = findViewById(R.id.lottieAnimationView2);
        ngo_login = findViewById(R.id.button14);
        ngo_login.setOnClickListener(view -> {
            Intent intent = new Intent(NgoLoginRegistration.this,NgoLogin.class);
            startActivity(intent);
        });
        ngo_reg = findViewById(R.id.button15);
        ngo_reg.setOnClickListener(view -> {
            Intent intent = new Intent(NgoLoginRegistration.this,NgoRegistration.class);
            startActivity(intent);
        });
    }
}
