package com.example.donation_app;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class DonorRequirements extends AppCompatActivity
{
    Button b6;
    EditText requirement;
    FirebaseAuth mAuth;
    FirebaseFirestore firebaseFirestore;
    String userID;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donor_requirements);
        mAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        requirement =  findViewById(R.id.editTextTextMultiLine);
        b6 = findViewById(R.id.button8);
        b6.setOnClickListener(view -> {
            // String Code
            String m_requirement = requirement.getText().toString().trim();
            if(TextUtils.isEmpty(m_requirement))
            {
                requirement.setError("Data is Required!!!");
            }
            userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
            DocumentReference documentReference = firebaseFirestore.collection("donors").document(userID);//.collection("Donor Requirement").document("Requirement");
            Map<String,Object> user = new HashMap<>();

            user.put("Requirement",m_requirement);
            documentReference.update(user).addOnSuccessListener(task -> Toast.makeText(DonorRequirements.this, "Data is Successfully Saved..", Toast.LENGTH_SHORT).show()).addOnFailureListener(t -> Toast.makeText(DonorRequirements.this, "Error Occurred: "+ t.getMessage(), Toast.LENGTH_SHORT).show());
            Intent intent = new Intent(DonorRequirements.this, ThankYou.class);
            startActivity(intent);
        });
    }
}