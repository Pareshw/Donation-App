package com.example.donation_app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

public class ThankYou extends AppCompatActivity
{
    Button b11;
    LottieAnimationView lottieAnimationView;
    @Override
    public void onCreate(Bundle saveInstanceState)
    {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.thank_you);
        lottieAnimationView =  findViewById(R.id.lottieAnimationView4);
        Toast.makeText(getApplicationContext(), "Your Post is Successfully Save ", Toast.LENGTH_SHORT).show();
        b11 = findViewById(R.id.button);
        b11.setOnClickListener(view -> {
            finishAffinity();
            System.exit(0);
        });
    }
}
