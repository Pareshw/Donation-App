package com.example.donation_app;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.Objects;

public class UserNgoRequirements extends AppCompatActivity
{
    RecyclerView recyclerView1;
    FirebaseFirestore firebaseFirestore;
    DonorAdapter donorAdapter;
    ArrayList<Donor> donorArrayList;
    ProgressDialog progressDialog;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_ngo_reuirement_page);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(true);
        progressDialog.setMessage("Fetching Data...");
        progressDialog.show();

        recyclerView1 = findViewById(R.id.recyclerView);
        recyclerView1.setHasFixedSize(true);
        recyclerView1.setLayoutManager(new LinearLayoutManager(this));

        donorArrayList = new ArrayList<>();
        donorAdapter = new DonorAdapter(UserNgoRequirements.this,donorArrayList);
        firebaseFirestore = FirebaseFirestore.getInstance();

        recyclerView1.setAdapter(donorAdapter);

        EventChange_Listener();
    }

        @SuppressLint("NotifyDataSetChanged")
        public void EventChange_Listener()
        {
            firebaseFirestore.collection("donors").orderBy("Donor_Name", Query.Direction.ASCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        if (progressDialog.isShowing())
                            progressDialog.dismiss();
                        Log.e("FireStore Error", error.getMessage());
                        return;
                    }
                    for (DocumentChange documentChange : Objects.requireNonNull(value).getDocumentChanges()) {
                        if (documentChange.getType() == DocumentChange.Type.ADDED) {
                            donorArrayList.add(documentChange.getDocument().toObject(Donor.class));
                        }

                        donorAdapter.notifyDataSetChanged();
                        if (progressDialog.isShowing())
                            progressDialog.dismiss();
                    }
                });

        }
}
