package com.example.donation_app;


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class NgoRequirements extends AppCompatActivity
{

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_ngo_reuirement_page);
    }
}
