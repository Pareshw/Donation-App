package com.example.donation_app;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.Objects;

public class NgoUserRequirement extends AppCompatActivity
{
    RecyclerView recyclerView;
    FirebaseFirestore firebaseFirestore;
    NgoAdapter ngoAdapter;
    ArrayList<Ngo> ngoArrayList;
    ProgressDialog progressDialog;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ngo_user_requirements);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(true);
        progressDialog.setMessage("Fetching Data...");
        progressDialog.show();

        recyclerView = findViewById(R.id.recyclerView_ngo);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ngoArrayList = new ArrayList<>();
        ngoAdapter = new NgoAdapter(NgoUserRequirement.this,ngoArrayList);
        firebaseFirestore = FirebaseFirestore.getInstance();

        recyclerView.setAdapter(ngoAdapter);

        EventChangeListener();

    }

    @SuppressLint("NotifyDataSetChanged")
    public void EventChangeListener()
    {
        firebaseFirestore.collection("users").orderBy("Donor_Name", Query.Direction.ASCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        if (progressDialog.isShowing())
                            progressDialog.dismiss();
                        Log.e("FireStore Error", error.getMessage());
                        return;
                    }
                    for (DocumentChange documentChange : Objects.requireNonNull(value).getDocumentChanges()) {
                        if (documentChange.getType() == DocumentChange.Type.ADDED) {
                            ngoArrayList.add(documentChange.getDocument().toObject(Ngo.class));
                        }

                        ngoAdapter.notifyDataSetChanged();
                        if (progressDialog.isShowing())
                            progressDialog.dismiss();
                    }
                });

    }
}
