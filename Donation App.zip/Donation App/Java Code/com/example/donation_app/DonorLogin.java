package com.example.donation_app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.airbnb.lottie.LottieAnimationView;
import com.google.firebase.auth.FirebaseAuth;

public class DonorLogin extends AppCompatActivity
{
    Button b14;
    EditText email,password;
    FirebaseAuth mAuth;
    LottieAnimationView lottieAnimationView;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donor_login);
        email = findViewById(R.id.editTextTextPersonName2);
        password = findViewById(R.id.editTextTextPassword2);
        mAuth = FirebaseAuth.getInstance();
        lottieAnimationView = findViewById(R.id.lottieAnimationView);
        b14 = findViewById(R.id.button2);
        b14.setOnClickListener(view -> {
            if (email.getText().toString().isEmpty())
            {
                Toast.makeText(DonorLogin.this, "Please enter your email!", Toast.LENGTH_SHORT).show();
            }
            else if (isEmailValid(email.getText().toString()))
            {
                Toast.makeText(DonorLogin.this, "Write a valid email!", Toast.LENGTH_SHORT).show();
            }
            else if (password.getText().toString().isEmpty())
            {
                Toast.makeText(DonorLogin.this, "Please enter your password!", Toast.LENGTH_SHORT).show();
            }
            else
            {
                mAuth.signInWithEmailAndPassword(email.getText().toString(), password.getText().toString()).addOnCompleteListener(task -> {
                    if (task.isSuccessful())
                    {
                        Toast.makeText(DonorLogin.this, "Login In Success!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(DonorLogin.this,DonorPortal.class);
                        startActivity(intent);
                    }
                }).addOnFailureListener(e -> Toast.makeText(DonorLogin.this, "Error in signing in: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
    private boolean isEmailValid(CharSequence email)
    {
        if (email == null)
        {
            return true;
        }
        else
        {
            return !Patterns.EMAIL_ADDRESS.matcher(email).matches();
        }
    }
}