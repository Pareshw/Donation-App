package com.example.donation_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class NgoPortal extends AppCompatActivity
{
    Button b7,b8,b9;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ngo_portal);
        b7 = findViewById(R.id.button6);
        b7.setOnClickListener(view -> {
            Intent intent = new Intent(NgoPortal.this,NgoUserRequirement.class);
            startActivity(intent);
        });

        b8 = findViewById(R.id.button7);
        b8.setOnClickListener(view -> {
            Intent intent = new Intent(NgoPortal.this,NgoRequirements.class);
            startActivity(intent);
        });

        b9 = findViewById(R.id.button5);
        b9.setOnClickListener(view -> {
            Intent intent = new Intent(NgoPortal.this,NgoPostRequirement.class);
            startActivity(intent);
        });
    }
}
