package com.example.donation_app;

import static java.lang.Thread.sleep;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class DonorRequirements extends AppCompatActivity
{
    Button b6,add_photo;
    EditText requirement;
    private final int IMG_REQUEST_ID = 1;
    Uri uri;
    FirebaseStorage storage;
    StorageReference storageReference;
    FirebaseAuth mAuth;
    FirebaseFirestore firebaseFirestore;
    UploadTask uploadTask;
    String userID;
    @SuppressWarnings("deprecation")
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donor_requirements);
        mAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        add_photo = findViewById(R.id.button10);
        requirement =  findViewById(R.id.editTextTextMultiLine);
        b6 = findViewById(R.id.button8);
        b6.setEnabled(false);
        add_photo.setOnClickListener(view -> {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent,"Select Picture"),IMG_REQUEST_ID);
            b6.setEnabled(true);
        });
        b6.setOnClickListener(view -> {
            // String Code
            String m_requirement = requirement.getText().toString().trim();
            if(TextUtils.isEmpty(m_requirement))
            {
                requirement.setError("Data is Required!!!");
            }
            userID = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
            DocumentReference documentReference = firebaseFirestore.collection("donors").document(userID);//.collection("Donor Requirement").document("Requirement");
            Map<String,Object> user = new HashMap<>();

            user.put("Requirement",m_requirement);
            documentReference.update(user).addOnSuccessListener(task -> Toast.makeText(DonorRequirements.this, "Data is Successfully Saved..", Toast.LENGTH_SHORT).show()).addOnFailureListener(t -> Toast.makeText(DonorRequirements.this, "Error Occurred: "+ t.getMessage(), Toast.LENGTH_SHORT).show());
            // Photo Code
            ProgressDialog progressDialog = new ProgressDialog(DonorRequirements.this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();
            if(uri != null)
            {
                progressDialog.dismiss();
                StorageReference reference = storageReference.child("picture/"+ System.currentTimeMillis());
                uploadTask = reference.putFile(uri);
                uploadTask.addOnCompleteListener(task -> {
                    if(task.isSuccessful())
                    {
                        try
                        {
                            sleep(3000);
                        } catch (InterruptedException e)
                        {
                            e.printStackTrace();
                        }
                        Intent intent = new Intent(DonorRequirements.this, ThankYou.class);
                        startActivity(intent);
                    }
                }).addOnFailureListener(exception -> Toast.makeText(DonorRequirements.this, "Error in uploading Image: "+ exception.getMessage(), Toast.LENGTH_SHORT).show()).addOnSuccessListener(taskSnapshot -> Toast.makeText(DonorRequirements.this, "Image is Successfully Upload...", Toast.LENGTH_SHORT).show());
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        super.onActivityResult(requestCode, resultCode, intent);
        if(requestCode == IMG_REQUEST_ID && resultCode == RESULT_OK && intent != null)
        {
            uri = intent.getData();
        }
    }
}